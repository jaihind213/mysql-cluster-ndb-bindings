// Test.cs created with MonoDevelop
// User: mtaylor at 4:45 PM 12/31/2007
//
// To change standard headers go to Edit->Preferences->Coding->Standard Headers
//

using System;
using NUnit.Framework;

namespace test
{
	
	
	[TestFixture()]
	public class Test
	{
		
		[Test()]
		public void TestCase()
		{
		}
	}
}
