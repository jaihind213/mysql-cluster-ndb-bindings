package com.mysql.cluster.mgmj;

public class CouldNotExitSigleUserMode extends NdbMgmException {

	protected static final long serialVersionUID = 1L;
	
	public CouldNotExitSigleUserMode(String message) {
		super(message);
	}

}
