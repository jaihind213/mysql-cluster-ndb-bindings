package com.mysql.cluster.mgmj;

public class AllocIDConfigMismatch extends NdbMgmException {

	protected static final long serialVersionUID = 1L;
	
	public AllocIDConfigMismatch(String message) {
		super(message);
	}

}
