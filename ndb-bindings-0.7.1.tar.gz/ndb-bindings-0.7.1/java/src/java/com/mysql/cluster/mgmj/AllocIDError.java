package com.mysql.cluster.mgmj;

public class AllocIDError extends NdbMgmException {

	protected static final long serialVersionUID = 1L;
	
	public AllocIDError(String message) {
		super(message);
	}

}
