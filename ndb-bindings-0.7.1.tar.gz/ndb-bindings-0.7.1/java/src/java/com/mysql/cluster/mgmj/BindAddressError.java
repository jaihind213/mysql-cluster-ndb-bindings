package com.mysql.cluster.mgmj;

public class BindAddressError extends NdbMgmException {

	protected static final long serialVersionUID = 1L;
	
	public BindAddressError(String message) {
		super(message);
	}

}
